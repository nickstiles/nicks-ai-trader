import React, { useState, useEffect, useCallback } from "react";
import axios from "axios";
import { Card, CardContent } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import logo from "../assets/logo.png";
import { ArrowUp, ArrowDown } from "lucide-react";

export default function Dashboard() {
  const [openTrades, setOpenTrades] = useState([]);
  const [closedTrades, setClosedTrades] = useState([]);
  const [signals, setSignals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchDashboardData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [openRes, closedRes, signalRes] = await Promise.all([
        axios.get("/api/trade/open"),
        axios.get("/api/trade/closed"),
        axios.get("/api/signal/latest"),
      ]);
      setOpenTrades(openRes.data);
      setClosedTrades(closedRes.data);
      setSignals(signalRes.data);
    } catch (err) {
      console.error("Dashboard fetch error:", err);
      setError("Failed to load data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial data load
  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  // SSE: refresh on server updates
  useEffect(() => {
    const es = new EventSource("api/trade/stream");
    es.onmessage = (e) => {
      try {
        JSON.parse(e.data); // you can inspect msg.type if needed
      } catch {}
      fetchDashboardData();
    };
    es.onerror = () => {
      console.warn("SSE connection error, closing");
      es.close();
    };
    return () => es.close();
  }, [fetchDashboardData]);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      {/* Header */}
      <header className="flex items-center mb-8">
        <img src={logo} alt="AI Trader Logo" className="h-12 w-12 mr-4" />
        <h1 className="text-3xl font-extrabold text-gray-800">AI Trader Dashboard</h1>
      </header>

      {/* Controls */}
      <div className="flex items-center justify-between mb-6">
        <Button onClick={fetchDashboardData} disabled={loading}>
          {loading ? "Refreshing..." : "Refresh Dashboard"}
        </Button>
        {error && <p className="text-red-600 font-medium">{error}</p>}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Signals */}
        <Card className="shadow-lg">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-4">Recent Signals</h2>
            {signals.length === 0 ? (
              <p className="text-gray-500 italic">No recent signals found.</p>
            ) : (
              <div className="space-y-3">
                {signals.map((s) => (
                  <Card key={s.option_symbol} className="border">
                    <CardContent className="p-4 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-lg">{s.ticker}</p>
                        <p className="text-sm text-gray-600">{s.option_symbol}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-mono">{(s.pred_return * 100).toFixed(1)}%</p>
                        <p className="text-sm text-gray-500">${s.option_price.toFixed(2)}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Trades */}
        <div className="space-y-6">
          {/* Open Trades */}
          <Card className="shadow-lg">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-4 flex justify-between items-center">
                <span>Open Trades</span>
                <span className="bg-blue-100 text-blue-800 rounded-full px-3 py-1 text-sm">
                  {openTrades.length}
                </span>
              </h2>
              {openTrades.length === 0 ? (
                <p className="text-gray-500 italic">No open trades found.</p>
              ) : (
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b text-gray-700">
                      <th className="py-2">Symbol</th>
                      <th>Qty</th>
                      <th>Entry</th>
                      <th>Current</th>
                      <th>PnL %</th>
                      <th>Placed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {openTrades.map((t) => {
                      const isUp = t.pnl_pct != null && t.pnl_pct >= 0;
                      return (
                        <tr key={t.db_id} className="border-b hover:bg-gray-50">
                          <td className="py-2 font-medium">{t.option_symbol}</td>
                          <td>{t.quantity}</td>
                          <td>${t.entry_price.toFixed(2)}</td>
                          <td>
                            {t.current_price != null ? `$${t.current_price.toFixed(2)}` : '—'}
                          </td>
                          <td className="flex items-center">
                            {t.pnl_pct != null ? (
                              <>
                                {isUp ? (
                                  <ArrowUp className="w-4 h-4 text-green-600 mr-1" />
                                ) : (
                                  <ArrowDown className="w-4 h-4 text-red-600 mr-1" />
                                )}
                                <span className={isUp ? "text-green-600" : "text-red-600"}>
                                  {(t.pnl_pct * 100).toFixed(2)}%
                                </span>
                              </>
                            ) : (
                              <span className="text-gray-500">—</span>
                            )}
                          </td>
                          <td>{new Date(t.placed_at).toLocaleString()}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </CardContent>
          </Card>

          {/* Closed Trades */}
          <Card className="shadow-lg">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-4 flex justify-between items-center">
                <span>Closed Trades</span>
                <span className="bg-green-100 text-green-800 rounded-full px-3 py-1 text-sm">
                  {closedTrades.length}
                </span>
              </h2>
              {closedTrades.length === 0 ? (
                <p className="text-gray-500 italic">No closed trades yet.</p>
              ) : (
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b text-gray-700">
                      <th className="py-2">Symbol</th>
                      <th>Exit</th>
                      <th>PnL $</th>
                      <th>PnL %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {closedTrades.map((t) => (
                      <tr key={t.db_id} className="border-b hover:bg-gray-50">
                        <td className="py-2 font-medium">{t.option_symbol}</td>
                        <td>${(t.exit_price ?? 0).toFixed(2)}</td>
                        <td className={t.pnl_dollars > 0 ? "text-green-600" : "text-red-600"}>
                          ${(t.pnl_dollars ?? 0).toFixed(2)}
                        </td>
                        <td>{((t.pnl_pct ?? 0) * 100).toFixed(2)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
